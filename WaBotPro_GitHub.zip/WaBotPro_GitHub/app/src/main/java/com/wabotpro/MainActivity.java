package com.wabotpro;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etMensagem;
    private RecyclerView rvGrupos;
    private GrupoAdapter adapter;
    private List<String> listaGrupos = new ArrayList<>();
    private Button btnAdicionarGrupo, btnIniciar, btnLimpar;
    private TextView tvStatus;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("wabotpro", MODE_PRIVATE);

        etMensagem = findViewById(R.id.etMensagem);
        rvGrupos = findViewById(R.id.rvGrupos);
        btnAdicionarGrupo = findViewById(R.id.btnAdicionarGrupo);
        btnIniciar = findViewById(R.id.btnIniciar);
        btnLimpar = findViewById(R.id.btnLimpar);
        tvStatus = findViewById(R.id.tvStatus);

        carregarGrupos();

        adapter = new GrupoAdapter(listaGrupos, pos -> {
            new AlertDialog.Builder(this)
                .setTitle("Remover Grupo")
                .setMessage("Remover \"" + listaGrupos.get(pos) + "\" da lista?")
                .setPositiveButton("Remover", (d, w) -> {
                    listaGrupos.remove(pos);
                    adapter.notifyDataSetChanged();
                    salvarGrupos();
                    atualizarStatus();
                })
                .setNegativeButton("Cancelar", null)
                .show();
        });

        rvGrupos.setLayoutManager(new LinearLayoutManager(this));
        rvGrupos.setAdapter(adapter);

        btnAdicionarGrupo.setOnClickListener(v -> mostrarDialogAdicionar());

        btnLimpar.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Limpar Lista")
                .setMessage("Remover todos os grupos?")
                .setPositiveButton("Limpar", (d, w) -> {
                    listaGrupos.clear();
                    adapter.notifyDataSetChanged();
                    salvarGrupos();
                    atualizarStatus();
                })
                .setNegativeButton("Cancelar", null)
                .show();
        });

        btnIniciar.setOnClickListener(v -> iniciarEnvio());

        atualizarStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        verificarAcessibilidade();
    }

    private void verificarAcessibilidade() {
        if (!isAccessibilityEnabled()) {
            new AlertDialog.Builder(this)
                .setTitle("⚠️ Permissão Necessária")
                .setMessage("O WaBot Pro precisa do Serviço de Acessibilidade para funcionar.\n\nVá em Configurações > Acessibilidade > WaBot Pro e ative.")
                .setPositiveButton("Abrir Configurações", (d, w) -> {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                })
                .setNegativeButton("Depois", null)
                .setCancelable(false)
                .show();
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> enabledServices =
            am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabledServices) {
            if (info.getId().contains(getPackageName())) return true;
        }
        return false;
    }

    private void mostrarDialogAdicionar() {
        EditText input = new EditText(this);
        input.setHint("Nome exato do grupo no WhatsApp Business");
        input.setPadding(40, 20, 40, 20);

        new AlertDialog.Builder(this)
            .setTitle("➕ Adicionar Grupo")
            .setMessage("Digite o nome exato do grupo como aparece no WhatsApp Business:")
            .setView(input)
            .setPositiveButton("Adicionar", (d, w) -> {
                String nome = input.getText().toString().trim();
                if (!nome.isEmpty()) {
                    listaGrupos.add(nome);
                    adapter.notifyDataSetChanged();
                    salvarGrupos();
                    atualizarStatus();
                    Toast.makeText(this, "Grupo adicionado!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Nome não pode ser vazio", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void iniciarEnvio() {
        if (!isAccessibilityEnabled()) {
            verificarAcessibilidade();
            return;
        }
        String mensagem = etMensagem.getText().toString().trim();
        if (mensagem.isEmpty()) {
            Toast.makeText(this, "⚠️ Digite uma mensagem!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (listaGrupos.isEmpty()) {
            Toast.makeText(this, "⚠️ Adicione ao menos um grupo!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Salva mensagem no clipboard e SharedPreferences para o serviço usar
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("mensagem", mensagem));

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("mensagem", mensagem);
        editor.putInt("grupoAtual", 0);
        editor.putBoolean("rodando", true);
        editor.apply();

        // Notifica o serviço
        Intent intent = new Intent(this, BotService.class);
        intent.putExtra("grupos", listaGrupos.toArray(new String[0]));
        intent.putExtra("mensagem", mensagem);
        startService(intent);

        Toast.makeText(this, "🚀 Iniciando envio...", Toast.LENGTH_LONG).show();

        // Abre WhatsApp Business
        try {
            Intent waIntent = getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");
            if (waIntent == null) waIntent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
            if (waIntent != null) {
                waIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(waIntent);
            } else {
                Toast.makeText(this, "WhatsApp Business não encontrado!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void atualizarStatus() {
        int total = listaGrupos.size();
        if (total == 0) {
            tvStatus.setText("Nenhum grupo na lista");
        } else {
            tvStatus.setText(total + " grupo(s) na fila");
        }
    }

    private void salvarGrupos() {
        JSONArray arr = new JSONArray();
        for (String g : listaGrupos) arr.put(g);
        prefs.edit().putString("grupos", arr.toString()).apply();
    }

    private void carregarGrupos() {
        String json = prefs.getString("grupos", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) listaGrupos.add(arr.getString(i));
        } catch (Exception e) { e.printStackTrace(); }
    }
}
