package com.wabotpro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class WaBotAccessibilityService extends AccessibilityService {

    private static final String TAG = "WaBotService";
    private static final String WA_BUSINESS = "com.whatsapp.w4b";
    private static final String WA_NORMAL = "com.whatsapp";

    private Handler handler = new Handler(Looper.getMainLooper());
    private List<String> grupos = new ArrayList<>();
    private String mensagem = "";
    private int grupoAtualIndex = 0;
    private boolean rodando = false;
    private String waPackage = WA_BUSINESS;

    // Estados da automação
    private enum Estado {
        AGUARDANDO, BUSCANDO_GRUPO, ABRINDO_GRUPO, COLANDO_MENSAGEM, ENVIANDO, PROXIMO_GRUPO
    }
    private Estado estado = Estado.AGUARDANDO;

    public static WaBotAccessibilityService instancia;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instancia = this;
        Log.d(TAG, "Serviço de Acessibilidade conectado");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!rodando) return;

        String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "";

        if (!pkg.equals(waPackage) && !pkg.equals(WA_NORMAL)) return;

        int tipo = event.getEventType();

        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            processarTela();
        }
    }

    public void iniciarBot(List<String> listaGrupos, String msg) {
        grupos = new ArrayList<>(listaGrupos);
        mensagem = msg;
        grupoAtualIndex = 0;
        rodando = true;
        estado = Estado.BUSCANDO_GRUPO;
        Log.d(TAG, "Bot iniciado com " + grupos.size() + " grupos");
        mostrarToast("🤖 Bot iniciado! Grupos: " + grupos.size());
    }

    private void processarTela() {
        if (!rodando || grupos.isEmpty()) return;
        if (grupoAtualIndex >= grupos.size()) {
            finalizarBot();
            return;
        }

        handler.postDelayed(this::tentarAcao, 1200);
    }

    private void tentarAcao() {
        if (!rodando) return;
        if (grupoAtualIndex >= grupos.size()) {
            finalizarBot();
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String grupoAlvo = grupos.get(grupoAtualIndex);

        switch (estado) {
            case BUSCANDO_GRUPO:
                buscarGrupo(root, grupoAlvo);
                break;
            case ABRINDO_GRUPO:
                // Aguarda abertura
                break;
            case COLANDO_MENSAGEM:
                colarMensagem(root);
                break;
            case ENVIANDO:
                enviarMensagem(root);
                break;
        }
    }

    private void buscarGrupo(AccessibilityNodeInfo root, String nomeGrupo) {
        // Tenta encontrar campo de busca
        List<AccessibilityNodeInfo> campos = root.findAccessibilityNodeInfosByViewId(waPackage + ":id/search_src_text");
        if (campos == null || campos.isEmpty()) {
            campos = root.findAccessibilityNodeInfosByViewId(WA_NORMAL + ":id/search_src_text");
        }

        if (campos != null && !campos.isEmpty()) {
            // Campo de busca aberto - digita o nome
            AccessibilityNodeInfo campo = campos.get(0);
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, nomeGrupo);
            campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            Log.d(TAG, "Buscando: " + nomeGrupo);

            handler.postDelayed(() -> encontrarEAbrirGrupo(nomeGrupo), 2000);
        } else {
            // Tenta abrir pesquisa
            abrirPesquisa(root, nomeGrupo);
        }
    }

    private void abrirPesquisa(AccessibilityNodeInfo root, String nomeGrupo) {
        // Procura ícone de busca
        List<AccessibilityNodeInfo> buscaNodes = new ArrayList<>();
        buscarPorDescricao(root, "search", buscaNodes);
        buscarPorDescricao(root, "Search", buscaNodes);
        buscarPorDescricao(root, "Buscar", buscaNodes);
        buscarPorDescricao(root, "Pesquisar", buscaNodes);

        if (!buscaNodes.isEmpty()) {
            buscaNodes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            handler.postDelayed(() -> buscarGrupo(getRootInActiveWindow(), nomeGrupo), 1500);
        } else {
            // Tenta encontrar o grupo diretamente na lista de conversas
            encontrarEAbrirGrupo(nomeGrupo);
        }
    }

    private void encontrarEAbrirGrupo(String nomeGrupo) {
        if (!rodando) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // Busca por texto exato ou parcial
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(nomeGrupo);
        if (nodes != null && !nodes.isEmpty()) {
            for (AccessibilityNodeInfo node : nodes) {
                // Sobe na árvore para encontrar item clicável
                AccessibilityNodeInfo clicavel = encontrarPaiClicavel(node);
                if (clicavel != null) {
                    clicavel.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    estado = Estado.COLANDO_MENSAGEM;
                    Log.d(TAG, "Grupo encontrado e clicado: " + nomeGrupo);
                    handler.postDelayed(() -> colarMensagem(getRootInActiveWindow()), 2500);
                    return;
                }
            }
        }

        Log.d(TAG, "Grupo não encontrado: " + nomeGrupo + " - tentando de novo...");
        handler.postDelayed(() -> tentarAcao(), 2000);
    }

    private void colarMensagem(AccessibilityNodeInfo root) {
        if (root == null) return;

        // Atualiza clipboard
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("msg", mensagem));

        // Procura campo de mensagem
        List<AccessibilityNodeInfo> campos = root.findAccessibilityNodeInfosByViewId(waPackage + ":id/entry");
        if (campos == null || campos.isEmpty()) {
            campos = root.findAccessibilityNodeInfosByViewId(WA_NORMAL + ":id/entry");
        }
        if (campos == null || campos.isEmpty()) {
            // Tenta por hint
            campos = root.findAccessibilityNodeInfosByText("Mensagem");
            if (campos == null || campos.isEmpty()) {
                campos = root.findAccessibilityNodeInfosByText("Message");
            }
        }

        if (campos != null && !campos.isEmpty()) {
            AccessibilityNodeInfo campo = campos.get(0);
            campo.performAction(AccessibilityNodeInfo.ACTION_CLICK);

            handler.postDelayed(() -> {
                // Cola usando SET_TEXT
                Bundle args = new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, mensagem);
                campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);

                estado = Estado.ENVIANDO;
                Log.d(TAG, "Mensagem colada!");
                mostrarToast("📝 Mensagem colada em: " + grupos.get(grupoAtualIndex));

                // Aguarda 5 segundos antes de enviar
                handler.postDelayed(() -> enviarMensagem(getRootInActiveWindow()), 5000);
            }, 800);
        } else {
            Log.d(TAG, "Campo de mensagem não encontrado - tentando novamente");
            handler.postDelayed(() -> colarMensagem(getRootInActiveWindow()), 2000);
        }
    }

    private void enviarMensagem(AccessibilityNodeInfo root) {
        if (root == null) return;

        // Procura botão de enviar
        List<AccessibilityNodeInfo> botoes = new ArrayList<>();
        buscarPorDescricao(root, "Send", botoes);
        buscarPorDescricao(root, "Enviar", botoes);

        List<AccessibilityNodeInfo> botoesId = root.findAccessibilityNodeInfosByViewId(waPackage + ":id/send");
        if (botoesId != null) botoes.addAll(botoesId);
        botoesId = root.findAccessibilityNodeInfosByViewId(WA_NORMAL + ":id/send");
        if (botoesId != null) botoes.addAll(botoesId);

        if (!botoes.isEmpty()) {
            botoes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            Log.d(TAG, "Mensagem enviada para: " + grupos.get(grupoAtualIndex));
            mostrarToast("✅ Enviado para: " + grupos.get(grupoAtualIndex));

            grupoAtualIndex++;

            if (grupoAtualIndex >= grupos.size()) {
                handler.postDelayed(this::finalizarBot, 1500);
            } else {
                // Próximo grupo - volta à tela principal
                estado = Estado.BUSCANDO_GRUPO;
                handler.postDelayed(this::voltarEBuscarProximo, 2000);
            }
        } else {
            Log.d(TAG, "Botão enviar não encontrado");
            handler.postDelayed(() -> enviarMensagem(getRootInActiveWindow()), 1500);
        }
    }

    private void voltarEBuscarProximo() {
        // Pressiona voltar para ir à lista de conversas
        performGlobalAction(GLOBAL_ACTION_BACK);
        handler.postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                buscarGrupo(root, grupos.get(grupoAtualIndex));
            }
        }, 1500);
    }

    private void finalizarBot() {
        rodando = false;
        estado = Estado.AGUARDANDO;
        Log.d(TAG, "Bot finalizado!");

        // Notifica MainActivity
        Intent intent = new Intent("com.wabotpro.FINALIZADO");
        sendBroadcast(intent);

        handler.post(() -> {
            Toast toast = Toast.makeText(getApplicationContext(),
                "✅ FINALIZADO! Mensagens enviadas para " + grupos.size() + " grupo(s)",
                Toast.LENGTH_LONG);
            toast.show();
        });

        // Abre o app novamente
        handler.postDelayed(() -> {
            Intent mainIntent = new Intent(this, MainActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            mainIntent.putExtra("finalizado", true);
            startActivity(mainIntent);
        }, 1000);
    }

    private AccessibilityNodeInfo encontrarPaiClicavel(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo atual = node;
        for (int i = 0; i < 8; i++) {
            if (atual == null) break;
            if (atual.isClickable()) return atual;
            atual = atual.getParent();
        }
        return null;
    }

    private void buscarPorDescricao(AccessibilityNodeInfo root, String desc, List<AccessibilityNodeInfo> resultado) {
        if (root == null) return;
        CharSequence cd = root.getContentDescription();
        if (cd != null && cd.toString().toLowerCase().contains(desc.toLowerCase())) {
            resultado.add(root);
        }
        for (int i = 0; i < root.getChildCount(); i++) {
            buscarPorDescricao(root.getChild(i), desc, resultado);
        }
    }

    private void mostrarToast(String msg) {
        handler.post(() -> Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show());
    }

    public boolean isRodando() { return rodando; }

    @Override
    public void onInterrupt() {
        rodando = false;
        Log.d(TAG, "Serviço interrompido");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instancia = null;
        rodando = false;
    }
}
