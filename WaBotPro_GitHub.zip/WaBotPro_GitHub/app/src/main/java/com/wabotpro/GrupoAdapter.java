package com.wabotpro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class GrupoAdapter extends RecyclerView.Adapter<GrupoAdapter.VH> {

    public interface OnDeleteListener { void onDelete(int pos); }

    private List<String> grupos;
    private OnDeleteListener listener;

    public GrupoAdapter(List<String> grupos, OnDeleteListener listener) {
        this.grupos = grupos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grupo, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        holder.tvNumero.setText(String.valueOf(position + 1));
        holder.tvNome.setText(grupos.get(position));
        holder.btnRemover.setOnClickListener(v -> listener.onDelete(holder.getAdapterPosition()));
    }

    @Override
    public int getItemCount() { return grupos.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvNumero, tvNome;
        ImageButton btnRemover;
        VH(View v) {
            super(v);
            tvNumero = v.findViewById(R.id.tvNumero);
            tvNome = v.findViewById(R.id.tvNome);
            btnRemover = v.findViewById(R.id.btnRemover);
        }
    }
}
