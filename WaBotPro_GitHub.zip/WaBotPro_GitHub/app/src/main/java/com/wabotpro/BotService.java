package com.wabotpro;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BotService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String[] gruposArr = intent.getStringArrayExtra("grupos");
            String mensagem = intent.getStringExtra("mensagem");
            if (gruposArr != null && mensagem != null) {
                List<String> grupos = new ArrayList<>(Arrays.asList(gruposArr));
                if (WaBotAccessibilityService.instancia != null) {
                    WaBotAccessibilityService.instancia.iniciarBot(grupos, mensagem);
                }
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
